package Packet;

// @author Ashime

import Utility.BytesUtils;
import Utility.Convert;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

public class PacketDecoder extends ChannelInboundHandlerAdapter
{
    Convert convert;
    BytesUtils util;
    
    private byte[] inPacket = {};
    
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg)
    {
        inPacket = (byte[]) msg;
        System.out.println("PD IN - channelRead()");
        decodePacket(ctx, inPacket);
    }
    
    private void decodePacket(ChannelHandlerContext ctx, byte[] msg)
    {
        System.out.println("PD IN - decodePacket()");
        byte[] bSize = {};
        int size = 0;
        
        // Flip the size bytes around.
        msg = util.flip(msg, 0, 1);
        
        // Split the size header off.
        bSize = util.split(msg, 0, 2);
        
        // Convert size from byte array into int.
        size = convert.byteArrayToInt(bSize);
        
        // Split message from size header
        msg = util.split(msg, 2, msg.length);
        
        System.out.println("SIZE: " + size + " MSG-LENGTH: " + msg.length);
        System.out.println("INPACKET: " + convert.byteArrayToHexString(msg));
       
        if(msg.length == size)
            // Passes the message down the pipeline.
            ctx.fireChannelRead(msg);  
        else
            // Drops the packet.
            ctx.fireChannelReadComplete();
    }
}
