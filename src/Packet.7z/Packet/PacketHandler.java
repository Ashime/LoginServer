package Packet;

import FileIO.IniFile;
import Interface.Console;
import Utility.Convert;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import java.net.SocketAddress;
import java.util.ArrayList;

// @author Ashime

/*
TODO:
1. Commenting
2. Code clean up
*/

public class PacketHandler extends ChannelDuplexHandler
{
    Console console = new Console();
    IniFile ini = new IniFile();
    LoginProtocol login = new LoginProtocol();
    Convert convert = new Convert();
    
    private static ArrayList<SocketAddress> clientAddress = new ArrayList<>();
    
    ByteBuf buffer = null;
    private final int bufferSize = ini.getBufferSize();

    
    
    @Override
    public void channelActive(ChannelHandlerContext ctx)
    {   
        buffer = ctx.alloc().buffer(bufferSize);
        System.out.println("PH IN - channelActive()");
        login.createPacket("HELLO");
        ctx.write(login.getCreatedPacket());
    }   
    
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg)
    {   
        System.out.println("PH IN - channelRead()");
        byte[] inPacket = (byte[]) msg;
        System.out.println("Message (" + convert.byteArrayToHexString(inPacket) + ") was retrieved from " + ctx.channel().remoteAddress());

        switch(inPacket[2]) // Category
        {
            case 51:
            {
                login.decodeMessage(inPacket);
                ctx.write(login.getCreatedPacket());
                break;
            }
            default:
            {
                System.out.println("Unknown category!");
                System.out.println(convert.byteArrayToHexString(inPacket));
                ctx.fireChannelReadComplete();
                break;
            }
        }
    }
    
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause)
    {
        console.displayMessage(3, cause.getMessage());
        ctx.flush();
        ctx.close();
    }

    // Getter
    public static ArrayList<SocketAddress> getClientAddress() {
        return clientAddress;
    }
}
