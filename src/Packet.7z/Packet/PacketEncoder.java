package Packet;

// @author Ashime

import Utility.BytesUtils;
import Utility.Convert;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageEncoder;
import java.util.Arrays;
import java.util.List;

 
public class PacketEncoder extends MessageToMessageEncoder <byte[]> //extends ChannelOutboundHandlerAdapter
{
    Convert convert = new Convert();
    BytesUtils util = new BytesUtils();

    @Override
    protected void encode(ChannelHandlerContext ctx, byte[] msg, List<Object> out)
    {
        byte[] outPacket = {};
        int size = 0;
        byte[] bSize = {};
        
        // Get size of the message.
        size = msg.length;
        
        // Convert size from int into byte array.
        bSize = convert.intToByteArray(size);
        
        // Add the size in front of the message.
        //outPacket = Arrays.copyOf(msg, (msg.length +2 ));
        // create a destination array that is the size of the two arrays
        outPacket = new byte[bSize.length + msg.length];

        // copy ciphertext into start of destination (from pos 0, copy ciphertext.length bytes)
        System.arraycopy(bSize, 0, outPacket, 0, bSize.length);

        // copy mac into end of destination (from pos ciphertext.length, copy mac.length bytes)
        System.arraycopy(msg, 0, outPacket, bSize.length, msg.length);

        // Flip the first two bytes.
        outPacket = util.flip(outPacket, 0, 1);
        
        System.out.println("OUTPACKET: " + convert.byteArrayToHexString(outPacket));
        
        out.add(Unpooled.wrappedBuffer(outPacket));
    }
}
