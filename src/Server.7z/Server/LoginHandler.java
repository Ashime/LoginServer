package Server;

import FileIO.IniFile;
import Interface.Console;
import Packet.LoginProtocol;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import java.io.UnsupportedEncodingException;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

// @author Ashime

/*
TODO:
1. Commenting
2. Code clean up
*/

public class LoginHandler extends ChannelDuplexHandler
{
    Console console = new Console();
    IniFile ini = new IniFile();
    LoginProtocol login = new LoginProtocol();
    
    private static ArrayList<SocketAddress> clientAddress = new ArrayList<>();
    
    ByteBuf buffer = null;
    private final int bufferSize = ini.getBufferSize();
    
    @Override
    public void channelActive(ChannelHandlerContext ctx)
    {
        buffer = ctx.alloc().buffer(bufferSize);
        addClient(ctx.channel().remoteAddress());
       // write(ctx, login.helloPacket);
        login.createPacket("HELLO");
        ctx.writeAndFlush(login.getCreatedPacket()); 
    }
    
    @Override
    public void channelInactive(ChannelHandlerContext ctx)
    {
        removeClient(ctx.channel().remoteAddress());
        ctx.close();
    }    
    
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg)
    {
        if(!ctx.channel().isOpen() || !ctx.channel().isActive())
            ctx.fireChannelInactive();
        
        byte[] inPacket = (byte[]) msg;
        
        login.decodeMessage(inPacket);
        ctx.writeAndFlush(login.getCreatedPacket());
    }
    
    public void write(ChannelHandlerContext ctx, byte[] msg)
    {
        if(!ctx.channel().isOpen() || !ctx.channel().isActive())
            ctx.fireChannelInactive();
        
        buffer = ctx.alloc().buffer(msg.length);
        buffer.writeBytes(msg);
        
        ChannelFuture future = ctx.writeAndFlush(buffer);
        
        future.addListener(new ChannelFutureListener() {
            @Override
            public void operationComplete(ChannelFuture future)
            {
                try {
                    String message = new String(msg, "US-ASCII");
                    System.out.println("Message (" + message + ") was sent to " + ctx.channel().remoteAddress());
                } catch (UnsupportedEncodingException ex) {
                    Logger.getLogger(LoginHandler.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }
    
    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws UnsupportedEncodingException
    {
        if(evt instanceof IdleStateEvent)
        {
            IdleStateEvent e = (IdleStateEvent) evt;
            
            if(e.state() == IdleState.READER_IDLE)
                ctx.fireChannelInactive();
            else if(e.state() == IdleState.WRITER_IDLE)
            {
                login.createPacket("ACCEPT");
                write(ctx, login.getCreatedPacket());
            }
        }
    }
    
    private void addClient(SocketAddress address)
    {
        if(!(clientAddress.contains(address)))
        {
            clientAddress.add(address);
        } 
    }
    
    private void removeClient(SocketAddress address)
    {
        if(clientAddress.contains(address))
        {
            clientAddress.remove(address);
        }
    }
    
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause)
    {
        console.displayMessage(3, cause.getMessage());
        ctx.flush();
        ctx.close();
    }

    // Getter
    public static ArrayList<SocketAddress> getClientAddress() {
        return clientAddress;
    }
}
