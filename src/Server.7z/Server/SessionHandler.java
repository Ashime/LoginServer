package Server;

// @author Ashime

import Utility.Convert;
import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPromise;
import java.io.UnsupportedEncodingException;
import java.net.SocketAddress;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
GENERAL INFORMATION:
This class is designed to handle all active sessions with currently
connected clients. Output: IP:Port,Key
*/

public class SessionHandler extends ChannelDuplexHandler
{
    Convert convert = new Convert();
    
    private static ArrayList<String> clientSession = new ArrayList<String>();
    private static String user;
    private static byte[] key = new byte[4];
    
    @Override
    public void channelActive(ChannelHandlerContext ctx)
    {
        addClient(ctx.channel().remoteAddress());
        System.out.println("SH IN - channelActive()");
        ctx.fireChannelActive();
    }
    
    @Override
    public void channelInactive(ChannelHandlerContext ctx)
    {
        String client = getUser(ctx.channel().remoteAddress());
        removeClient(client);
        ctx.close();
    }
    
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg)
    {
        byte[] inPacket = (byte[]) msg;
        System.out.println("SH IN - channelRead()");
        ctx.fireChannelRead(inPacket);
    }
    
    @Override
     public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise)
    {
        System.out.println("SH OUT - write()");
        
        if(!ctx.channel().isOpen() || !ctx.channel().isActive())
            ctx.fireChannelInactive();
        
        ctx.writeAndFlush(msg);
    }
    
    public void addClient(SocketAddress address)
    {
        generateKey();
        user = address.toString() + "," + convert.byteArrayToHexString(key);
        clientSession.add(user);
    }
    
    public void removeClient(String user)
    {
        clientSession.remove(user);
    }
    
    private void generateKey()
    {
        try{ SecureRandom.getInstanceStrong().nextBytes(key); } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(SessionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private String getUser(SocketAddress address)
    {
        String client = "";
        
        for(String temp : clientSession)
        {
            if(client.contains(address.toString()))
            {
                client = temp;
                break;
            }
        }
        
        return client;
    }
}
